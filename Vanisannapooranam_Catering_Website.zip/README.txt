VANISANNAPOORANAM CATERING WEBSITE

Files:
- index.html: complete responsive website.

HOW TO PUBLISH FREE:
1. Create a free GitHub account at github.com.
2. Create a new PUBLIC repository named: vanisannapooranam
3. Upload index.html.
4. Go to Settings -> Pages.
5. Under Build and deployment, choose "Deploy from a branch".
6. Select main branch and / (root), then Save.
7. GitHub will give you a free address similar to:
   https://YOUR-USERNAME.github.io/vanisannapooranam/

NOTE:
- The website currently uses no external images, so it works immediately.
- You can later add real food photos and a logo.
- Phone and WhatsApp buttons are already configured for 7395927918.
